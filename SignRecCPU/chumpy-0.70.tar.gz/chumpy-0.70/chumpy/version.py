version = '0.70'
short_version = version
full_version = version
